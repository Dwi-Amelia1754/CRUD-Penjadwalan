<?php
  header('location:'); 
?>