<html>
<head>
<meta http-equiv="refresh" content="5; url=../index.php">
<title>:: PSB Online - Sistem Pendaftaran Siswa Baru(PSB) Online</title>
</head>
<body>
<h1>ANDA TIDAK BERHAK MENGAKSES HALAMAN INI..........!</h1>
<?php echo "<meta http-equiv='refresh' content='0; url=../index.php'>"; ?>
</body>
</html>
