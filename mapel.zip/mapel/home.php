<style type="text/css">
<!--
.style1 {
	font-family: "Colonna MT";
	font-size: 17px;
}
.style2 {font-family: "Tw Cen MT";
}
.style4 {font-size: 16px}
-->
</style>
<span class="style1"><center>SELAMAT DATANG DI SISTEM INFORMASI PENJADWALAM MATA PELAJARAN</center></span>
<hr>
<div align="justify" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Alhamdulillah  berkat rahmat dan ridho Allah SWT serta dukungan dari&nbsp;semua&nbsp;keluarga  besar SMP N 35 Berasrama Kaur, kami telah melakukan perbaikan-perbaikan web SMP N 35 Berasrama Kaur. Kami menyadari bahwa web ini masih banyak kelemahan-kelemahan  dan kekurangannya dan untuk kedepan kami akan selalu memperbaikinya dalam  rangka untuk menunjang perbaikan kualitas pendidikan. Semoga Allah SWT selalu  meridhoi segala usaha kita dalam upaya meningkatkan mutu pendidikan.<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Web SMP N 35 Berasrama Kaur dibuat sebagai media informasi dan komunikasi yang efektif bagi keluarga besar SMP N 40 PadangBerasrama Kaur dan masyarakat luas yang memerlukan informasi yang akurat, lengkap, utuh  dan terpecaya tentang SMP N 35 Berasrama Kaur.<br />
  </span></p>
<div align="justify" >Terima kasih kami sampaikan  kepada semua pihak, semoga Web ini dapat bermanfaat dan berguna sebagai mana  mestinya. Dan kami selalu menunggu saran dan masukan.</div>
</div>
<br><br><br><br><br><br>